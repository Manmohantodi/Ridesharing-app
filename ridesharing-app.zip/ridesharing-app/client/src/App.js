// src/App.js
import React, { useEffect, useState } from 'react';
import UserRequestForm from './components/UserRequestForm';

function App() {
    const [drivers, setDrivers] = useState([]);
    const [rideRequests, setRideRequests] = useState([]);

    useEffect(() => {
        fetch('http://localhost:3001/api/drivers')
            .then(response => response.json())
            .then(data => setDrivers(data))
            .catch(error => console.error('Error fetching drivers:', error));
    }, []);

    const handleRideRequest = (userData) => {
        // Find available driver (This is just a simple example; you can enhance the logic)
        const availableDriver = drivers.find(driver => driver.available);
        if (availableDriver) {
            // Update driver availability (mark as unavailable)
            availableDriver.available = false;
            // Add request to the rideRequests state
            setRideRequests([...rideRequests, { ...userData, driver: availableDriver.name }]);
            alert(`Ride assigned to ${availableDriver.name}`);
        } else {
            alert('No drivers available at the moment');
        }
    };

    return (
        <div>
            <h1>Welcome to the Peer-to-Peer Ridesharing System</h1>
            <h2>Available Drivers:</h2>
            <ul>
                {drivers.map(driver => (
                    <li key={driver.id}>
                        {driver.name} - {driver.location} {driver.available ? '(Available)' : '(Not Available)'}
                    </li>
                ))}
            </ul>
            <UserRequestForm onRequest={handleRideRequest} />
            <h2>Ride Requests:</h2>
            <ul>
                {rideRequests.map((request, index) => (
                    <li key={index}>{request.userName} requested a ride with {request.driver} from {request.userLocation}</li>
                ))}
            </ul>
        </div>
    );
}

export default App;
