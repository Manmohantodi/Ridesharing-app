const config = {
    contractAddress: '0xAD978B5Cf5ce80D94bb6DAd357DF06572425417e', // Replace with your actual deployed contract address
    network: 'Sepolia', // Adjust if needed
};

export default config;
