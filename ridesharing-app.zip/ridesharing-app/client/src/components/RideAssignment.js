import React from 'react';

function RideAssignment() {
  return (
    <div>
      <h2>Ride Assignment</h2>
      <p>Details about the assigned ride will be shown here.</p>
    </div>
  );
}

export default RideAssignment;
