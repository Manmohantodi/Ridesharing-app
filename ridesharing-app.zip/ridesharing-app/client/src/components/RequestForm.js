// src/components/UserRequestForm.js
import React, { useState } from 'react';

const UserRequestForm = ({ onRequest }) => {
    const [userName, setUserName] = useState('');
    const [userLocation, setUserLocation] = useState('');

    const handleSubmit = (e) => {
        e.preventDefault();
        // Call the onRequest function passed down as a prop with user data
        onRequest({ userName, userLocation });
        setUserName(''); // Reset the form
        setUserLocation('');
    };

    return (
        <form onSubmit={handleSubmit}>
            <input
                type="text"
                placeholder="Your Name"
                value={userName}
                onChange={(e) => setUserName(e.target.value)}
                required
            />
            <input
                type="text"
                placeholder="Your Location"
                value={userLocation}
                onChange={(e) => setUserLocation(e.target.value)}
                required
            />
            <button type="submit">Request Ride</button>
        </form>
    );
};

export default UserRequestForm;
