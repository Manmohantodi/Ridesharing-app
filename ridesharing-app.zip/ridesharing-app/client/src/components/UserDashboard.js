import React, { useState } from 'react';
import { ethers } from 'ethers';
import abi from '../abi.json';
import config from '../config';

function UserDashboard() {
  const [location, setLocation] = useState('');
  const [rideStatus, setRideStatus] = useState(null);

  const requestRide = async () => {
    if (!window.ethereum) {
      alert('Please install MetaMask to make a payment');
      return;
    }

    try {
      // Request account access
      await window.ethereum.request({ method: 'eth_requestAccounts' });

      // Create a provider and signer
      const provider = new ethers.providers.Web3Provider(window.ethereum);
      const signer = provider.getSigner();

      // Create a contract instance
      const ridePaymentContract = new ethers.Contract(config.contractAddress, abi, signer);

      // Define the payment amount (e.g., 0.01 ETH)
      const paymentAmount = ethers.utils.parseEther('0.01');

      // Request the ride with payment
      const transaction = await ridePaymentContract.requestRide('DRIVER_ADDRESS', { value: paymentAmount });
      await transaction.wait(); // Wait for the transaction to be mined

      setRideStatus({ message: 'Ride requested and payment sent successfully!' });
    } catch (error) {
      console.error('Payment error:', error);
      setRideStatus({ message: 'Error processing payment. Please try again.' });
    }
  };

  return (
    <div>
      <h2>User Dashboard</h2>
      <input
        type="text"
        placeholder="Enter your location"
        value={location}
        onChange={(e) => setLocation(e.target.value)}
      />
      <button onClick={requestRide}>Request Ride & Pay</button>
      {rideStatus && (
        <div>
          <h3>Ride Status</h3>
          <p>{rideStatus.message}</p>
        </div>
      )}
    </div>
  );
}

export default UserDashboard;
