import React, { useEffect, useState } from 'react';

function DriverDashboard() {
  const [drivers, setDrivers] = useState([]);

  useEffect(() => {
    // Fetch drivers from the server
    fetch('/api/drivers')
      .then((res) => res.json())
      .then((data) => setDrivers(data));
  }, []);

  return (
    <div>
      <h2>Driver Dashboard</h2>
      {drivers.map((driver) => (
        <div key={driver.id}>
          <p>Name: {driver.name}</p>
          <p>Location: {driver.location}</p>
        </div>
      ))}
    </div>
  );
}

export default DriverDashboard;
