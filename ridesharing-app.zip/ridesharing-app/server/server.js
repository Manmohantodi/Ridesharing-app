// server/server.js
const express = require('express');
const app = express();
const driversData = require('./driversData'); // Ensure the path is correct

// Route to fetch drivers
app.get('/api/drivers', (req, res) => {
    console.log(driversData); // Log the data to the console for debugging
    res.json(driversData); // Send the data as a JSON response
});

const PORT = 3001;
app.listen(PORT, () => {
    console.log(`Server running at http://localhost:${PORT}`);
});
