// server/driversData.js
module.exports = [
    { id: 1, name: 'Driver A', location: 'Mumbai', available: true },
    { id: 2, name: 'Driver B', location: 'Delhi', available: true },
    { id: 3, name: 'Driver C', location: 'Bangalore', available: true }
    // Add more drivers if needed
];
